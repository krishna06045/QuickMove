import { useState, useCallback } from "react";
import { toast } from "sonner";

export function useValidationWorkflow() {
  const [approvedFields, setApprovedFields] = useState<Record<string, boolean>>({});
  const [rejectedFields, setRejectedFields] = useState<Record<string, boolean>>({});

  const approveField = useCallback((key: string, label: string) => {
    setApprovedFields(prev => ({ ...prev, [key]: true }));
    setRejectedFields(prev => ({ ...prev, [key]: false }));
    toast.success(`${label} approved and locked.`);
  }, []);

  const rejectField = useCallback((key: string, label: string) => {
    setRejectedFields(prev => ({ ...prev, [key]: true }));
    setApprovedFields(prev => ({ ...prev, [key]: false }));
    toast.error(`${label} rejected. Needs manual review.`);
  }, []);

  const resetField = useCallback((key: string) => {
    setApprovedFields(prev => ({ ...prev, [key]: false }));
    setRejectedFields(prev => ({ ...prev, [key]: false }));
  }, []);

  return {
    approvedFields,
    rejectedFields,
    approveField,
    rejectField,
    resetField,
  };
}
